from cv2 import *
import numpy as np
import os

path = "C:/Users/felip/Pictures/Nova pasta/"

f = open(path + "1test.arff", "w+")
f.close()

f = open(path + "1test.arff", "a+")
f.write("@relation IRN\n")
for k in range(300):
    f.write("@attribute entr{} numeric\n".format(k))
f.write("\n@data\n")
f.close()

f = open(path + "1test.arff", "w+")
f.close()

f = open(path + "1test.arff", "a+")
f.write("@relation IRN\n")
for k in range(299):
    f.write("@attribute entr{} numeric\n".format(k))
f.write("\n@data\n")
f.close()

print("Inicio do arquivo teste", end=" ")
a = imread(path + "1test.png", 2)
#a = imread(path + "/{}".format(file), 2)

#print(a.shape)
n = 255 - a
#imshow('teste', a)
#%imshow('teste 1', n)
#waitKey(0)
[h,w] = a.shape
lin = [0]*h
lin = np.zeros(h, dtype=float)
col = np.zeros(w, dtype=float)
for i in range(h):
    for j in range(w):
        if (n[i,j]!=0):
            lin[i]=lin[i]+1
            col[j]=col[j]+1

minI = maxI = -1
for i in range(h):
    if (minI<0 and lin[i]>0):
        minI=i
    if (maxI < 0 and lin[h-i-1]>0):
        maxI = h-i-1
#print(minI, maxI)

minJ = maxJ = -1
for j in range(w):
    if (minJ<0 and col[j]>0):
        minJ=j
    if (maxJ < 0 and col[w-j-1]>0):
        maxJ = w-j-1
#print(minJ, maxJ)
nH = (maxI - minI + 1)
nW = (maxJ - minJ + 1)

x = n[minI:maxI,minJ:maxJ].copy()
#imshow('roi', x)
#waitKey(0)

#print(lins)
#print(cols)
#print([nH, nW])

nH = 200
nW = 100
r = resize(x, (nW, nH))
#imshow('R', r)
#waitKey(0)
lin = np.zeros(nH, dtype=float)
col = np.zeros(nW, dtype=float)
for i in range(nH):
    for j in range(nW):
        if (r[i,j]!=0):
            lin[i]=lin[i]+1
            col[j]=col[j]+1

lins = 100*lin.copy()/nW
cols = 100*col.copy()/nH

f = open(path + "1test.arff", "a+")

for i in range(len(lins)):
    f.write("{}\t".format(lins[i]))
for j in range(len(cols)):
    f.write("{}\t".format(cols[j]))

f.close()
print("Done!")
print("The End")